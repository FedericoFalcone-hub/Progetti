/**
 * Package contenente lo sviluppo del progetto "Mole", sviluppato da Federico Falcone 41253A.
 * Il progetto è stato svolto attraverso il supporto di risorse in rete e materiale didattico. E' stato utilizzato GitHub Copilot e chatGPT per ottenere spunti di riflessione.
 * Il codice implementato è stato pensato e sviluppato da me.
 */
package mole;
